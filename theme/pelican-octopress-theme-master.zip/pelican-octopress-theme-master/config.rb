# config file for compass
project_type = :stand_alone

http_images_path = "../images"
css_dir = "static/css"

sass_dir = "sass"
images_dir = "static/images"

line_comments = false
output_style = :compressed
